import os, asyncio, random
from telethon import TelegramClient, errors
from dotenv import load_dotenv

load_dotenv()
API_ID = int(os.getenv("TELEGRAM_API_ID"))
API_HASH = os.getenv("TELEGRAM_API_HASH")

# Your 5 setup sessions
SESSIONS = [".telegram_session", "catherine_session", "mara_session", "jasmine_session", "alaska_session"]

async def main():
    # Load progress to continue where you left off
    idx = 0
    if os.path.exists('last_sent.txt'):
        with open('last_sent.txt', 'r') as f:
            idx = int(f.read().strip())

    if not os.path.exists('targets.txt'):
        print("Error: targets.txt not found.")
        return

    with open('targets.txt', 'r') as f:
        targets = [l.strip().replace('@', '') for l in f if l.strip()]

    for session in SESSIONS:
        if idx >= len(targets): break
        print(f"--- Using Account: {session} ---")
        
        async with TelegramClient(session, API_ID, API_HASH) as client:
            while idx < len(targets):
                user = targets[idx]
                try:
                    msg = (
                        "Hi, We are launching a new iGaming platform this week and seeking one "
                        "professional team to lead all marketing and growth operations.\n\n"
                        "The Role:\nFull ownership of the marketing funnel, including Social Media, "
                        "Banner Promotions, and CSR initiatives.\n\n"
                        "The Terms:\n• Weekly settlements\n• Full dashboard tracking\n\n"
                        "📩 TO APPLY: Message @XeniaXu8 with your experience and 1st-month targets."
                    )
                    
                    await client.send_message(user, msg)
                    print(f"✅ [{session}] Sent to {user} (List # {idx + 1})")
                    
                    idx += 1
                    with open('last_sent.txt', 'w') as f: f.write(str(idx))
                    await asyncio.sleep(random.randint(120, 240))
                
                except errors.PeerFloodError:
                    print(f"⚠️ Account {session} hit limit. Switching...")
                    break
                except (errors.UsernameNotOccupiedError, errors.UserIdInvalidError):
                    print(f"❌ User {user} deleted/changed. Skipping.")
                    idx += 1
                    continue
                except Exception as e:
                    print(f"❌ Error: {e}")
                    idx += 1
                    continue
    print("Batch finished or all targets reached.")

if __name__ == "__main__":
    asyncio.run(main())
